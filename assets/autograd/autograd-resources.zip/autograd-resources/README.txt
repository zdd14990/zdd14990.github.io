Autograd 1.9.1, commit f53a21734fdfae636f448744d9097d8d35a643a0

运行说明和逐篇入口：
https://zdd14990.github.io/blog/applied-math/autograd/00-overview/#experiments

实验与 Mini Python 文件是教材原文；lesson01 和 debug_walkthrough 的本机路径常量须按上述说明配置。
